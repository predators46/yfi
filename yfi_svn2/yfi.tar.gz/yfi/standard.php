 Hello, I'm a <h1>standard</h1> page
<?
   // phpinfo();
?>


