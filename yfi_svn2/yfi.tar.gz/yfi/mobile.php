 Hello, I'm a <h1>mobile</h1> page

<?
   // phpinfo();
?>


