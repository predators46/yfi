<?php

class Radgroupcheck extends AppModel {

    var $name       = 'Radgroupcheck';
    var $useTable   = 'radgroupcheck';
}

?>