<?
class Radreply extends AppModel {
    var $name       = 'Radreply';
    var $useTable   = 'radreply';

}
?>