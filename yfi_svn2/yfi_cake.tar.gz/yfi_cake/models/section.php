<?
class Section extends AppModel {
    var $name       = 'Section';
}
?>