<?php

class Radgroupreply extends AppModel {

    var $name       = 'Radgroupreply';
    var $useTable   = 'radgroupreply';
}

?>