<?php

class Invoice extends AppModel {


}

?>