<?
class ExtraService extends AppModel {
    var $name       = 'ExtraService';

}
?>