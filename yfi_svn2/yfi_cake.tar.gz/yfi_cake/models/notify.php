<?
class Notify extends AppModel {
    var $name       = 'Notify';
    var $useTable   = 'notifications';

}
?>