<?php

class Payment extends AppModel {


}

?>