<?
class AutoContact extends AppModel {
    var $name       = 'AutoContact';


}
?>