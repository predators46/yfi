<?
class Radacct extends AppModel {
    var $name       = 'Radacct';
    var $useTable   = 'radacct';
    var $primaryKey = 'radacctid';

    /*
    var $hasMany = array(
        'Voucher' => array(
            'className'  => 'Voucher',
            'conditions' => array(),
            'order'      => 'Voucher.created DESC'
        )
    );
    */
}
?>
