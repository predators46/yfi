<?php
class TransactionDetailsController extends AppController {

	var $name = 'TransactionDetails';

    var $scaffold;
}
?>



