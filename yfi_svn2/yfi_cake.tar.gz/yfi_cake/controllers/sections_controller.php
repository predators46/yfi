<?
class SectionsController extends AppController {
    var $name       = 'Sections';
    var $helpers    = array('Javascript');

    var $components = array('Session');    //Add the locker component

    var $scaffold;

}
?>