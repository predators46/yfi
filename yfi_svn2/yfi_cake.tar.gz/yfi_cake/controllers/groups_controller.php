<?
class GroupsController extends AppController {
    var $name       = 'Groups';
    var $helpers    = array('Javascript');

    var $components = array('Session');    //Add the locker component

    var $scaffold;

}
?>