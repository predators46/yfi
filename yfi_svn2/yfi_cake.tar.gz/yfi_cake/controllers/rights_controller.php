<?
class RightsController extends AppController {
    var $name       = 'Rights';
    var $helpers    = array('Javascript');

    var $components = array('Session');    //Add the locker component

    var $scaffold;

}
?>