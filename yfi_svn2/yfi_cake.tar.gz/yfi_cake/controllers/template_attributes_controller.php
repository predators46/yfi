<?
class TemplateAttributesController extends AppController {
    var $name       = 'TemplateAttributes';
    var $helpers    = array('Javascript');

    var $components = array('Session');    //Add the locker component

    //var $scaffold;

}
?>