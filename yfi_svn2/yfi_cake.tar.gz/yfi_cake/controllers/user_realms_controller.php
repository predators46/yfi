<?
class UserRealmsController extends AppController {
    var $name       = 'UserRealms';
    var $helpers    = array('Javascript');

    var $components = array('Session');    //Add the locker component

    //var $scaffold;

}
?>